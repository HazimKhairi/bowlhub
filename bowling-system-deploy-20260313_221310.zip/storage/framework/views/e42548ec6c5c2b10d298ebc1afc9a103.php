<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Ukhuwah Strike Challenge - Sistem Kejohanan Boling'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-brand">
                <i class="fas fa-bowling-ball"></i>
                <span>Ukhuwah Strike Challenge</span>
            </div>
            <ul class="nav-menu">
                <?php if(session('admin_logged_in')): ?>
                    <li><a href="<?php echo e(route('home')); ?>" class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">Utama</a></li>
                    <li><a href="<?php echo e(route('leaderboard')); ?>" class="nav-link <?php echo e(request()->routeIs('leaderboard') ? 'active' : ''); ?>">Kedudukan</a></li>
                    <li><a href="<?php echo e(route('admin')); ?>" class="nav-link <?php echo e(request()->routeIs('admin') ? 'active' : ''); ?>">Admin</a></li>
                    <li>
                        <form id="logoutForm" method="POST" action="<?php echo e(route('admin.logout')); ?>">
                            <?php echo csrf_field(); ?>
                        </form>
                        <a href="#" onclick="document.getElementById('logoutForm').submit()" class="nav-link">Logout</a>
                    </li>
                <?php else: ?>
                    <li><a href="<?php echo e(route('home')); ?>" class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">Utama</a></li>
                    <li><a href="<?php echo e(route('leaderboard')); ?>" class="nav-link <?php echo e(request()->routeIs('leaderboard') ? 'active' : ''); ?>">Kedudukan</a></li>
                    <li><a href="<?php echo e(route('registration')); ?>" class="nav-link <?php echo e(request()->routeIs('registration') ? 'active' : ''); ?>">Pendaftaran</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="main-content">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Toast Notification -->
    <div class="toast" id="toast"></div>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Users/radhifauzan/Desktop/side-projects/bowling-system-backend/resources/views/layouts/app.blade.php ENDPATH**/ ?>