<?php $__env->startSection('title', 'Kemaskini Skor - ' . $participant->name); ?>

<?php $__env->startSection('content'); ?>
<div class="section active">
    <h2 class="section-title">Kemaskini Skor</h2>

    <div class="participant-info" style="margin-bottom: 2rem;">
        <p><strong>ID:</strong> <?php echo e($participant->id); ?></p>
        <p><strong>Nama:</strong> <?php echo e($participant->name); ?></p>
        <p><strong>Pasukan:</strong> <?php echo e($participant->team); ?></p>
        <p><strong>Acara:</strong> <?php echo e($participant->event_type); ?> (<?php echo e($participant->gender); ?>)</p>
    </div>

    <form id="scoreEditForm" action="<?php echo e(route('admin.score.update', $participant->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="scores-grid">
            <div class="form-group">
                <label for="editG1">Game 1</label>
                <input type="number" id="editG1" name="g1" min="0" max="300" required value="<?php echo e($participant->score->g1 ?? 0); ?>">
            </div>
            <div class="form-group">
                <label for="editG2">Game 2</label>
                <input type="number" id="editG2" name="g2" min="0" max="300" required value="<?php echo e($participant->score->g2 ?? 0); ?>">
            </div>
            <div class="form-group">
                <label for="editG3">Game 3</label>
                <input type="number" id="editG3" name="g3" min="0" max="300" required value="<?php echo e($participant->score->g3 ?? 0); ?>">
            </div>
            <div class="form-group">
                <label for="editG4">Game 4</label>
                <input type="number" id="editG4" name="g4" min="0" max="300" required value="<?php echo e($participant->score->g4 ?? 0); ?>">
            </div>
            <div class="form-group">
                <label for="editG5">Game 5</label>
                <input type="number" id="editG5" name="g5" min="0" max="300" required value="<?php echo e($participant->score->g5 ?? 0); ?>">
            </div>
        </div>
        <div class="score-summary">
            <div class="summary-item">
                <span>Jumlah:</span>
                <strong id="editTotalScore"><?php echo e($participant->score->total ?? 0); ?></strong>
            </div>
            <div class="summary-item">
                <span>Purata:</span>
                <strong id="editAvgScore"><?php echo e($participant->score->average ?? 0); ?></strong>
            </div>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="<?php echo e(route('admin')); ?>" class="btn btn-secondary">Kembali</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
const editInputs = ['editG1', 'editG2', 'editG3', 'editG4', 'editG5'];

editInputs.forEach(id => {
    document.getElementById(id).addEventListener('input', updateEditScoreSummary);
});

function updateEditScoreSummary() {
    const scores = editInputs.map(id => parseInt(document.getElementById(id).value) || 0);
    const total = scores.reduce((a, b) => a + b, 0);
    const avg = (total / 5).toFixed(1);

    document.getElementById('editTotalScore').textContent = total;
    document.getElementById('editAvgScore').textContent = avg;
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/radhifauzan/Desktop/side-projects/bowling-system-backend/resources/views/admin/score-edit.blade.php ENDPATH**/ ?>